package kr.or.ddit.vo;

import lombok.Data;

@Data
public class AcademyVO {
	private String id;
	private String name;
	private String parentId;
}
