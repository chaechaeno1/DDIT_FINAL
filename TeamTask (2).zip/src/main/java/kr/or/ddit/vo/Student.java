package kr.or.ddit.vo;

import lombok.Data;

@Data
public class Student {
	
	private int stId;
	private String stName;
	private String tel;
	private String majorType;
	private String certificate;
	private String grade;

}
